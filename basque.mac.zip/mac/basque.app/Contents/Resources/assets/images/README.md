Original links for these assets (both Public Domain):

https://opengameart.org/content/zelda-like-tilesets-and-sprites

https://opengameart.org/content/the-field-of-the-floating-islands
